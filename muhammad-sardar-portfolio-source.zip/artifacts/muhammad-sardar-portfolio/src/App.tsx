import { type ReactNode, useEffect, useState } from 'react';
import { QueryClient, QueryClientProvider } from '@tanstack/react-query';
import {
  ArrowDownRight,
  ArrowUpRight,
  Check,
  ChevronDown,
  Code2,
  ExternalLink,
  Menu,
  MoveUpRight,
  Palette,
  PanelTop,
  PenTool,
  Send,
  Smartphone,
  Sparkles,
  X,
} from 'lucide-react';
import { ErrorBoundary } from '@/components/error-boundary';
import { Toaster } from '@/components/ui/toaster';
import { TooltipProvider } from '@/components/ui/tooltip';
import NotFound from '@/pages/not-found';
import {
  Route,
  Switch,
  useLocation,
  Router as WouterRouter,
} from 'wouter';
import portraitPath from '@assets/muhammad-sardar-portrait.png';

const queryClient = new QueryClient();
const whatsappUrl = 'https://wa.me/923139602114';

const navItems = [
  { label: 'About', href: '#about' },
  { label: 'Capabilities', href: '#capabilities' },
  { label: 'Process', href: '#process' },
  { label: 'Work', href: '#work' },
];

const buildTypes = [
  {
    number: '01',
    title: 'Business Websites',
    copy: 'Clear, considered websites that give a business a sharper digital presence.',
    icon: PanelTop,
  },
  {
    number: '02',
    title: 'Restaurant & Café Websites',
    copy: 'Warm, inviting digital spaces that make menus, atmosphere and next steps easy to find.',
    icon: Sparkles,
  },
  {
    number: '03',
    title: 'Landing Pages',
    copy: 'Focused pages with a strong point of view, built to make the next step obvious.',
    icon: ArrowUpRight,
  },
  {
    number: '04',
    title: 'Custom Web Experiences',
    copy: 'Responsive interface work where visual rhythm and usability need to agree.',
    icon: Smartphone,
  },
];

const process = [
  ['01', 'Understand', 'We clarify the purpose, audience and practical shape of the website.'],
  ['02', 'Plan', 'The structure, content direction and visual route become tangible.'],
  ['03', 'Design', 'A composed interface gives the idea a clear and memorable point of view.'],
  ['04', 'Build', 'Clean, responsive code turns the approved direction into a working website.'],
  ['05', 'Refine', 'Details are checked across screen sizes until the experience feels right.'],
  ['06', 'Deliver', 'You receive the completed website code/files, ready for your chosen setup.'],
];

const skills = [
  'HTML',
  'CSS',
  'JavaScript',
  'Responsive Web Design',
  'Replit',
  'AI-assisted website development',
];

function scrollToId(id: string) {
  document.querySelector(id)?.scrollIntoView({ behavior: 'smooth', block: 'start' });
}

function useRevealOnScroll() {
  useEffect(() => {
    const elements = document.querySelectorAll<HTMLElement>('.reveal');
    if (!('IntersectionObserver' in window)) {
      elements.forEach((element) => element.classList.add('is-visible'));
      return;
    }
    const observer = new IntersectionObserver(
      (entries) => entries.forEach((entry) => {
        if (entry.isIntersecting) {
          entry.target.classList.add('is-visible');
          observer.unobserve(entry.target);
        }
      }),
      { threshold: 0.12 },
    );
    elements.forEach((element) => observer.observe(element));
    return () => observer.disconnect();
  }, []);
}

function Header({ menuOpen, setMenuOpen }: { menuOpen: boolean; setMenuOpen: (value: boolean) => void }) {
  const navigate = (href: string) => {
    setMenuOpen(false);
    scrollToId(href);
  };
  return (
    <header className="fixed left-0 right-0 top-0 z-20 border-b border-[hsl(var(--border)/.75)] bg-[hsl(var(--background)/.88)] backdrop-blur-md">
      <div className="mx-auto flex h-[74px] max-w-[1360px] items-center justify-between px-5 sm:px-8 lg:px-12">
        <button type="button" onClick={() => scrollToId('#top')} className="focus-ring group flex items-center gap-3" data-testid="button-home">
          <span className="grid h-8 w-8 place-items-center rounded-full bg-[hsl(var(--foreground))] font-mono-custom text-[10px] font-medium text-[hsl(var(--background))] transition-transform group-hover:rotate-12">MS</span>
          <span className="font-display text-[15px] font-semibold tracking-[-.02em]" data-testid="text-brand">Muhammad Sardar</span>
        </button>
        <nav className="hidden items-center gap-8 md:flex" aria-label="Main navigation">
          {navItems.map((item) => (
            <button key={item.href} type="button" onClick={() => navigate(item.href)} className="line-draw focus-ring font-mono-custom text-[10px] uppercase tracking-[.16em] text-[hsl(var(--muted-foreground))] transition-colors hover:text-[hsl(var(--foreground))]" data-testid={`link-nav-${item.label.toLowerCase()}`}>
              {item.label}
            </button>
          ))}
        </nav>
        <a href={whatsappUrl} target="_blank" rel="noreferrer" className="hidden items-center gap-2 border-b border-[hsl(var(--foreground))] pb-1 font-mono-custom text-[10px] uppercase tracking-[.14em] md:flex" data-testid="link-header-whatsapp">
          Start a conversation <ArrowUpRight className="h-3.5 w-3.5" />
        </a>
        <button type="button" onClick={() => setMenuOpen(!menuOpen)} aria-expanded={menuOpen} aria-label={menuOpen ? 'Close menu' : 'Open menu'} className="focus-ring grid h-10 w-10 place-items-center md:hidden" data-testid="button-mobile-menu">
          {menuOpen ? <X className="h-5 w-5" /> : <Menu className="h-5 w-5" />}
        </button>
      </div>
      <div className={`overflow-hidden border-t border-[hsl(var(--border)/.75)] bg-[hsl(var(--background))] transition-[max-height,opacity] duration-300 md:hidden ${menuOpen ? 'max-h-96 opacity-100' : 'max-h-0 opacity-0'}`}>
        <nav className="mx-auto flex max-w-[1360px] flex-col px-5 py-5 sm:px-8" aria-label="Mobile navigation">
          {navItems.map((item, index) => (
            <button key={item.href} type="button" onClick={() => navigate(item.href)} className="flex items-center justify-between border-b border-[hsl(var(--border)/.8)] py-4 text-left font-display text-2xl" data-testid={`link-mobile-${item.label.toLowerCase()}`}>
              <span>{item.label}</span><span className="font-mono-custom text-xs text-[hsl(var(--muted-foreground))]">0{index + 1}</span>
            </button>
          ))}
          <a href={whatsappUrl} target="_blank" rel="noreferrer" className="mt-5 flex items-center justify-between rounded-full bg-[hsl(var(--foreground))] px-5 py-3 font-mono-custom text-[10px] uppercase tracking-[.15em] text-[hsl(var(--background))]" data-testid="link-mobile-whatsapp">
            WhatsApp: 0313 9602114 <ArrowUpRight className="h-4 w-4" />
          </a>
        </nav>
      </div>
    </header>
  );
}

function SectionLabel({ index, children }: { index: string; children: ReactNode }) {
  return (
    <div className="mb-8 flex items-center gap-3 font-mono-custom text-[10px] uppercase tracking-[.18em] text-[hsl(var(--muted-foreground))]">
      <span className="grid h-6 w-6 place-items-center rounded-full border border-[hsl(var(--border))] text-[9px]">{index}</span>
      <span>{children}</span>
    </div>
  );
}

function Home() {
  const [menuOpen, setMenuOpen] = useState(false);
  const [showTop, setShowTop] = useState(false);
  useRevealOnScroll();

  useEffect(() => {
    const handleScroll = () => setShowTop(window.scrollY > 700);
    window.addEventListener('scroll', handleScroll, { passive: true });
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  return (
    <div className="portfolio-shell noise min-h-[100dvh] overflow-hidden" id="top">
      <div className="site-grid pointer-events-none absolute inset-x-0 top-0 h-[950px] opacity-70" />
      <Header menuOpen={menuOpen} setMenuOpen={setMenuOpen} />
      <main className="relative">
        <section className="mx-auto grid min-h-[760px] max-w-[1360px] items-center gap-14 px-5 pb-24 pt-36 sm:px-8 lg:grid-cols-[1.08fr_.92fr] lg:gap-20 lg:px-12 lg:pb-28 lg:pt-44" aria-labelledby="hero-title">
          <div className="relative z-[1]">
            <div className="reveal mb-8 flex items-center gap-3 font-mono-custom text-[10px] uppercase tracking-[.2em] text-[hsl(var(--muted-foreground))]">
              <span className="h-2 w-2 rounded-full bg-[hsl(var(--secondary))]" />
              Independent web developer / Pakistan
            </div>
            <h1 id="hero-title" className="reveal reveal-delay-1 max-w-[800px] font-display text-[clamp(4.2rem,9.5vw,9.2rem)] font-semibold leading-[.84] tracking-[-.075em] text-[hsl(var(--foreground))]" data-testid="text-hero-name">
              Muhammad<br /><span className="ml-[.35em] text-[hsl(var(--accent))]">Sardar</span>
            </h1>
            <div className="reveal reveal-delay-2 mt-10 flex max-w-[660px] flex-col gap-7 sm:ml-[16%] sm:flex-row sm:items-start sm:gap-10">
              <p className="max-w-[280px] font-mono-custom text-[11px] uppercase leading-[1.7] tracking-[.15em] text-[hsl(var(--muted-foreground))]" data-testid="text-hero-role">Freelance Web Developer</p>
              <p className="max-w-[355px] font-display text-xl leading-[1.25] tracking-[-.02em] sm:text-2xl" data-testid="text-hero-statement">Building modern, responsive websites for businesses.</p>
            </div>
            <div className="reveal reveal-delay-3 mt-12 flex flex-wrap items-center gap-4 sm:ml-[16%]">
              <a href={whatsappUrl} target="_blank" rel="noreferrer" className="focus-ring group flex items-center gap-4 rounded-full bg-[hsl(var(--foreground))] px-5 py-3.5 font-mono-custom text-[10px] uppercase tracking-[.13em] text-[hsl(var(--background))]" data-testid="link-hero-whatsapp">
                Contact Me on WhatsApp <span className="grid h-6 w-6 place-items-center rounded-full bg-[hsl(var(--secondary))] text-[hsl(var(--foreground))] transition-transform group-hover:rotate-45"><ArrowUpRight className="h-3.5 w-3.5" /></span>
              </a>
              <button type="button" onClick={() => scrollToId('#work')} className="focus-ring group flex items-center gap-2 px-2 py-3 font-mono-custom text-[10px] uppercase tracking-[.13em] text-[hsl(var(--muted-foreground))]" data-testid="button-view-work">
                View My Work <ArrowDownRight className="h-4 w-4 transition-transform group-hover:translate-y-1" />
              </button>
            </div>
          </div>
          <div className="reveal reveal-delay-2 relative mx-auto w-full max-w-[510px] lg:mt-16">
            <div className="absolute -right-2 -top-10 z-[1] hidden h-28 w-28 rounded-full border border-[hsl(var(--foreground)/.2)] sm:block">
              <span className="absolute left-1/2 top-1/2 -translate-x-1/2 -translate-y-1/2 font-mono-custom text-[9px] uppercase tracking-[.12em]">craft<br />over<br />noise</span>
            </div>
            <div className="portrait-frame relative aspect-[.9] overflow-hidden rounded-[10rem_10rem_1.25rem_1.25rem] border border-[hsl(var(--foreground)/.2)] bg-[hsl(var(--muted))]">
              <img src={portraitPath} alt="Muhammad Sardar working at a laptop" className="h-full w-full object-cover object-center grayscale-[.12] transition-transform duration-700 hover:scale-[1.03]" data-testid="img-portrait" />
              <div className="absolute bottom-4 left-4 rounded-full bg-[hsl(var(--background)/.88)] px-3 py-2 font-mono-custom text-[9px] uppercase tracking-[.14em] backdrop-blur-sm">Available for select projects</div>
            </div>
            <div className="absolute -bottom-8 -left-4 hidden max-w-[185px] rotate-[-5deg] bg-[hsl(var(--accent))] px-4 py-3 font-display text-lg leading-[1] sm:block">Good websites make the next step feel natural.</div>
          </div>
        </section>

        <section id="about" className="scroll-mt-24 border-t border-[hsl(var(--border))] bg-[hsl(var(--foreground))] text-[hsl(var(--background))]" aria-labelledby="about-title">
          <div className="mx-auto grid max-w-[1360px] gap-12 px-5 py-24 sm:px-8 lg:grid-cols-[.8fr_1.2fr] lg:gap-24 lg:px-12 lg:py-32">
            <div className="reveal">
              <SectionLabel index="01">About the work</SectionLabel>
              <p className="max-w-[280px] font-mono-custom text-[11px] uppercase leading-[1.7] tracking-[.13em] text-[hsl(var(--background)/.55)]">A small, focused practice for thoughtful digital work.</p>
            </div>
            <div className="reveal reveal-delay-1">
              <h2 id="about-title" className="max-w-[900px] font-display text-[clamp(2.6rem,5vw,5.6rem)] font-medium leading-[.94] tracking-[-.065em]">Websites should feel <span className="text-[hsl(var(--secondary))]">clear</span>, useful and quietly memorable.</h2>
              <p className="mt-10 max-w-[680px] text-lg leading-[1.65] text-[hsl(var(--background)/.68)]" data-testid="text-about">I’m Muhammad Sardar, an independent freelance web developer from Pakistan. I focus on creating modern, responsive websites with clean design, smooth user experiences and strong visual presentation.</p>
              <div className="mt-12 grid max-w-[700px] gap-5 border-t border-[hsl(var(--background)/.2)] pt-6 sm:grid-cols-2">
                <div><p className="font-mono-custom text-[10px] uppercase tracking-[.16em] text-[hsl(var(--background)/.45)]">Approach</p><p className="mt-2 font-display text-xl">Less noise. Better decisions.</p></div>
                <div><p className="font-mono-custom text-[10px] uppercase tracking-[.16em] text-[hsl(var(--background)/.45)]">Working model</p><p className="mt-2 font-display text-xl">Direct, project-based, focused.</p></div>
              </div>
            </div>
          </div>
        </section>

        <section id="capabilities" className="scroll-mt-24 mx-auto max-w-[1360px] px-5 py-24 sm:px-8 lg:px-12 lg:py-32" aria-labelledby="capabilities-title">
          <div className="reveal flex flex-col justify-between gap-7 sm:flex-row sm:items-end">
            <div><SectionLabel index="02">What I build</SectionLabel><h2 id="capabilities-title" className="max-w-[680px] font-display text-[clamp(3rem,6vw,6.2rem)] font-semibold leading-[.88] tracking-[-.07em]">Built for the <span className="text-[hsl(var(--accent))]">real world.</span></h2></div>
            <p className="max-w-[270px] text-sm leading-[1.65] text-[hsl(var(--muted-foreground))]">A website can be simple without being ordinary. These are the kinds of digital spaces I enjoy making.</p>
          </div>
          <div className="mt-16 grid border-t border-[hsl(var(--border))] sm:grid-cols-2 lg:grid-cols-4">
            {buildTypes.map(({ number, title, copy, icon: Icon }, index) => (
              <article key={title} className={`reveal reveal-delay-${(index % 3) + 1} group border-b border-[hsl(var(--border))] px-1 py-8 sm:nth-[odd]:border-r lg:border-b-0 lg:border-r lg:px-7 lg:py-10 lg:first:pl-0 lg:last:border-r-0`} data-testid={`card-build-${number}`}>
                <div className="flex items-start justify-between"><span className="font-mono-custom text-[10px] text-[hsl(var(--muted-foreground))]">{number}</span><Icon className="h-5 w-5 text-[hsl(var(--muted-foreground))] transition-transform duration-300 group-hover:-translate-y-1 group-hover:translate-x-1" strokeWidth={1.5} /></div>
                <h3 className="mt-14 font-display text-2xl font-medium tracking-[-.04em]">{title}</h3>
                <p className="mt-4 max-w-[230px] text-sm leading-[1.65] text-[hsl(var(--muted-foreground))]">{copy}</p>
              </article>
            ))}
          </div>
        </section>

        <section id="process" className="scroll-mt-24 bg-[hsl(var(--accent))] px-5 py-24 sm:px-8 lg:px-12 lg:py-32" aria-labelledby="process-title">
          <div className="mx-auto max-w-[1360px]">
            <div className="reveal grid gap-8 lg:grid-cols-[.75fr_1.25fr]">
              <div><SectionLabel index="03">The process</SectionLabel><h2 id="process-title" className="max-w-[450px] font-display text-[clamp(3.2rem,6vw,6rem)] font-semibold leading-[.87] tracking-[-.07em]">From first thought to <span className="text-[hsl(var(--background))]">finished.</span></h2></div>
              <p className="max-w-[420px] self-end text-sm leading-[1.7] text-[hsl(var(--foreground)/.7)]">Good work gets better when the path is visible. The process stays collaborative, practical and intentionally small.</p>
            </div>
            <div className="mt-20 grid border-t border-[hsl(var(--foreground)/.25)] md:grid-cols-2 lg:grid-cols-3">
              {process.map(([number, title, copy], index) => (
                <article key={number} className={`reveal reveal-delay-${(index % 3) + 1} min-h-[205px] border-b border-[hsl(var(--foreground)/.25)] py-7 md:px-7 md:nth-[odd]:border-r lg:px-8 lg:nth-[3n+1]:pl-0 lg:nth-[3n+2]:border-r lg:nth-[3n]:border-r-0`} data-testid={`card-process-${number}`}>
                  <span className="font-mono-custom text-[10px] text-[hsl(var(--foreground)/.62)]">{number}</span>
                  <h3 className="mt-12 font-display text-2xl tracking-[-.035em]">{title}</h3>
                  <p className="mt-3 max-w-[270px] text-sm leading-[1.55] text-[hsl(var(--foreground)/.68)]">{copy}</p>
                </article>
              ))}
            </div>
          </div>
        </section>

        <section className="border-b border-[hsl(var(--border))] bg-[hsl(var(--muted)/.55)] px-5 py-24 sm:px-8 lg:px-12 lg:py-32" aria-labelledby="skills-title">
          <div className="mx-auto grid max-w-[1360px] gap-14 lg:grid-cols-[.8fr_1.2fr] lg:gap-24">
            <div className="reveal"><SectionLabel index="04">Tools & instincts</SectionLabel><h2 id="skills-title" className="font-display text-[clamp(3rem,5vw,5.2rem)] font-semibold leading-[.88] tracking-[-.07em]">The details are<br /><span className="text-[hsl(var(--accent-foreground))]">the work.</span></h2></div>
            <div className="reveal reveal-delay-1 grid grid-cols-1 border-t border-[hsl(var(--border))] sm:grid-cols-2">
              {skills.map((skill, index) => <div key={skill} className="flex items-center gap-3 border-b border-[hsl(var(--border))] py-4 text-sm"><Check className="h-4 w-4 text-[hsl(var(--accent))]" strokeWidth={2.5} /><span data-testid={`text-skill-${index}`}>{skill}</span></div>)}
            </div>
          </div>
        </section>

        <section id="work" className="scroll-mt-24 mx-auto max-w-[1360px] px-5 py-24 sm:px-8 lg:px-12 lg:py-32" aria-labelledby="work-title">
          <div className="reveal flex flex-col justify-between gap-7 border-b border-[hsl(var(--border))] pb-10 sm:flex-row sm:items-end">
            <div><SectionLabel index="05">Selected work</SectionLabel><h2 id="work-title" className="font-display text-[clamp(3rem,6vw,6.2rem)] font-semibold leading-[.86] tracking-[-.07em]">Room for<br /><span className="text-[hsl(var(--accent))]">what&apos;s next.</span></h2></div>
            <p className="max-w-[300px] text-sm leading-[1.65] text-[hsl(var(--muted-foreground))]">A replaceable shelf for future work. No invented clients, screenshots or claims — just space for projects to earn their place.</p>
          </div>
          <div className="mt-12 grid gap-5 lg:grid-cols-[1.25fr_.75fr]">
            <article className="reveal group min-h-[410px] overflow-hidden border border-[hsl(var(--border))] bg-[hsl(var(--muted)/.65)] p-5 sm:p-8" data-testid="card-work-placeholder-01">
              <div className="work-placeholder relative flex min-h-[280px] flex-col justify-between overflow-hidden border border-[hsl(var(--border))] p-5 sm:min-h-[350px] sm:p-8">
                <div className="flex items-center justify-between font-mono-custom text-[10px] uppercase tracking-[.15em] text-[hsl(var(--muted-foreground))]"><span>Selected work / 01</span><ExternalLink className="h-4 w-4" /></div>
                <div><span className="inline-block bg-[hsl(var(--accent))] px-2 py-1 font-mono-custom text-[9px] uppercase tracking-[.14em]">Replaceable placeholder</span><h3 className="mt-4 max-w-[500px] font-display text-4xl font-medium leading-[.9] tracking-[-.06em] sm:text-6xl">Your next<br />strong first impression.</h3></div>
              </div>
            </article>
            <div className="grid gap-5 sm:grid-cols-2 lg:grid-cols-1">
              {['Selected work / 02', 'Selected work / 03'].map((label, index) => (
                <article key={label} className={`reveal reveal-delay-${index + 1} work-placeholder flex min-h-[250px] flex-col justify-between border border-[hsl(var(--border))] p-5 sm:p-7`} data-testid={`card-work-placeholder-0${index + 2}`}>
                  <div className="flex items-center justify-between font-mono-custom text-[10px] uppercase tracking-[.15em] text-[hsl(var(--muted-foreground))]"><span>{label}</span><MoveUpRight className="h-4 w-4" /></div>
                  <div><p className="font-display text-3xl leading-[.95] tracking-[-.05em]">{index === 0 ? 'A space for a project in progress.' : 'A space for work worth showing.'}</p><p className="mt-3 font-mono-custom text-[9px] uppercase tracking-[.12em] text-[hsl(var(--muted-foreground))]">Details to be added</p></div>
                </article>
              ))}
            </div>
          </div>
        </section>

        <section id="contact" className="scroll-mt-24 bg-[hsl(var(--foreground))] px-5 py-24 text-[hsl(var(--background))] sm:px-8 lg:px-12 lg:py-36" aria-labelledby="contact-title">
          <div className="mx-auto max-w-[1360px]">
            <div className="reveal flex items-center gap-3 font-mono-custom text-[10px] uppercase tracking-[.2em] text-[hsl(var(--background)/.52)]"><span className="h-2 w-2 rounded-full bg-[hsl(var(--secondary))]" />Have a website idea?</div>
            <h2 id="contact-title" className="reveal reveal-delay-1 mt-8 max-w-[1000px] font-display text-[clamp(4rem,10vw,10rem)] font-semibold leading-[.8] tracking-[-.08em]">Let&apos;s<br /><span className="text-[hsl(var(--secondary))]">build it.</span></h2>
            <div className="reveal reveal-delay-2 mt-14 flex flex-col justify-between gap-10 border-t border-[hsl(var(--background)/.2)] pt-7 md:flex-row md:items-end">
              <p className="max-w-[430px] text-base leading-[1.7] text-[hsl(var(--background)/.65)]">I work on a project basis and deliver the completed website code/files. Hosting and deployment can be handled by the client or their team.</p>
              <div className="flex flex-col items-start gap-4">
                <a href={whatsappUrl} target="_blank" rel="noreferrer" className="focus-ring group flex items-center gap-6 rounded-full bg-[hsl(var(--secondary))] px-6 py-4 font-mono-custom text-[11px] uppercase tracking-[.14em] text-[hsl(var(--foreground))]" data-testid="link-contact-whatsapp">Contact Us on WhatsApp <span className="grid h-7 w-7 place-items-center rounded-full bg-[hsl(var(--foreground))] text-[hsl(var(--secondary))] transition-transform group-hover:rotate-45"><Send className="h-3.5 w-3.5" /></span></a>
                <span className="font-mono-custom text-[9px] uppercase tracking-[.14em] text-[hsl(var(--background)/.45)]">Email placeholder — add address when ready</span>
              </div>
            </div>
          </div>
        </section>
      </main>
      <footer className="bg-[hsl(var(--foreground))] px-5 pb-8 text-[hsl(var(--background))] sm:px-8 lg:px-12">
        <div className="mx-auto flex max-w-[1360px] flex-col justify-between gap-7 border-t border-[hsl(var(--background)/.2)] pt-7 sm:flex-row sm:items-center">
          <p className="font-mono-custom text-[10px] uppercase tracking-[.14em] text-[hsl(var(--background)/.5)]">Muhammad Sardar / Freelance Web Developer / Pakistan</p>
          <div className="flex items-center gap-6 font-mono-custom text-[10px] uppercase tracking-[.14em]">
            <a href="https://github.com/" target="_blank" rel="noreferrer" className="line-draw focus-ring text-[hsl(var(--background)/.7)]" data-testid="link-github-placeholder">GitHub placeholder</a>
            <button type="button" onClick={() => scrollToId('#top')} className="focus-ring flex items-center gap-2 text-[hsl(var(--background)/.7)]" data-testid="button-back-to-top">Back to top <ChevronDown className="h-3.5 w-3.5 rotate-180" /></button>
          </div>
        </div>
      </footer>
      <button type="button" onClick={() => scrollToId('#top')} aria-label="Back to top" className={`focus-ring fixed bottom-6 right-5 z-10 grid h-11 w-11 place-items-center rounded-full bg-[hsl(var(--secondary))] text-[hsl(var(--foreground))] shadow-[var(--shadow-md)] transition-all duration-300 sm:right-8 ${showTop ? 'translate-y-0 opacity-100' : 'pointer-events-none translate-y-4 opacity-0'}`} data-testid="button-floating-top"><ChevronDown className="h-4 w-4 rotate-180" /></button>
    </div>
  );
}

function Router() {
  return (
    <RoutedErrorBoundary>
      <Switch>
        <Route path="/" component={Home} />
        <Route component={NotFound} />
      </Switch>
    </RoutedErrorBoundary>
  );
}

function RoutedErrorBoundary({ children }: { children: ReactNode }) {
  const [location] = useLocation();
  return <ErrorBoundary resetKey={location}>{children}</ErrorBoundary>;
}

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <TooltipProvider>
        <WouterRouter base={import.meta.env.BASE_URL.replace(/\/$/, '')}>
          <Router />
        </WouterRouter>
        <Toaster />
      </TooltipProvider>
    </QueryClientProvider>
  );
}

export default App;