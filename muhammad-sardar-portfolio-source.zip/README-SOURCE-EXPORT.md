# Muhammad Sardar Portfolio — Source Export

This archive contains the complete Replit workspace source, including the portfolio web app, the supplied portrait asset, shared workspace packages, and the project package/lock configuration. Installed dependencies, generated build output, Replit-local caches, and Git metadata are excluded.

## Run the portfolio locally

Requirements: Node.js and pnpm.

1. Extract this archive.
2. From the extracted project root, install dependencies: `pnpm install`
3. Start the portfolio: `pnpm --filter @workspace/muhammad-sardar-portfolio run dev`

For a production build, run: `PORT=5173 BASE_PATH=/ pnpm --filter @workspace/muhammad-sardar-portfolio run build`

The website source is in `artifacts/muhammad-sardar-portfolio/`. The portrait used by the site is in `attached_assets/muhammad-sardar-portrait.png`. The portfolio uses WhatsApp contact `https://wa.me/923139602114`.
